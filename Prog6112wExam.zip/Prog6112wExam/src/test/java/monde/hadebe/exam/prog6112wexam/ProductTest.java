/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package monde.hadebe.exam.prog6112wexam;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author apple
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductTest {

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {

        String[] products = {
            "Single Mattress",
            "Double Mattress",
            "Queen Mattress"
        };

        int[][] sales = {
            {120, 150, 180},
            {200, 170, 190},
            {250, 230, 270}
        };

        Product product = new Product(products, sales);

        assertEquals(1760, product.GetTotalProductsSold());
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {

        String[] products = {
            "Single Mattress",
            "Double Mattress",
            "Queen Mattress"
        };

        int[][] sales = {
            {120, 150, 180},
            {200, 170, 190},
            {250, 230, 270}
        };

        Product product = new Product(products, sales);

        assertEquals(586.67,
                product.GetAverageProductSold(), 0.01);
    }
}