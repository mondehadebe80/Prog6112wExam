package monde.hadebe.exam.prog6112wexam;


public class ProductSalesReport {

    public static void main(String[] args) {

        String[] products = {
            "Single Mattress",
            "Double Mattress",
            "Queen Mattress"
        };

        int[][] sales = {
            {120, 150, 180},
            {200, 170, 190},
            {250, 230, 270}
        };

        Product product = new Product(products, sales);
        PrintProduct print = new PrintProduct(product);

        System.out.println("MATTRESS SALES REPORT");
        System.out.println("-----------------------------------------------");

        System.out.printf("%-20s %-8s %-8s %-8s%n",
                "PRODUCT", "JAN", "FEB", "MAR");

        System.out.println("-----------------------------------------------");

        for (int i = 0; i < products.length; i++) {
            System.out.printf("%-20s %-8d %-8d %-8d%n",
                    products[i],
                    sales[i][0],
                    sales[i][1],
                    sales[i][2]);
        }

        System.out.println("-----------------------------------------------");

        System.out.print("Total Products" + product.GetTotalProductsSold());
        System.out.print("Average Products" + product.GetAverageProductSold());
        System.out.print("Most Popular Products" + product.GetMostPopularProduct());
    }
}