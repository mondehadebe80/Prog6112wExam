package monde.hadebe.exam.prog6112wexam2;


public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}