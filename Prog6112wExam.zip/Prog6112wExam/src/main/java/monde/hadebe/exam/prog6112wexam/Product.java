package monde.hadebe.exam.prog6112wexam;


public class Product implements IProduct {

    private String[] products;
    private int[][] sales;

    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;

        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductSold() {
        return (double) GetTotalProductsSold() / products.length;
    }

    @Override
    public String GetMostPopularProduct() {
        int highest = -1;
        String popular = "";

        for (int i = 0; i < products.length; i++) {
            int total = 0;

            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }

            if (total > highest) {
                highest = total;
                popular = products[i];
            }
        }

        return popular;
    }
}