package monde.hadebe.exam.prog6112wexam2;


import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

public class MattressSalesGUI extends JFrame {

    private JTextField customerField;
    private JTextField priceField;
    private JComboBox<String> productCombo;
    private JTextArea reportArea;

    public MattressSalesGUI() {

        setTitle("Mattress Sales Application");
        setSize(550, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Menu system
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 20, 10, 20)
        );

        customerField = new JTextField();

        productCombo = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        });

        priceField = new JTextField();

        inputPanel.add(new JLabel("Customer Name:"));
        inputPanel.add(customerField);

        inputPanel.add(new JLabel("Product Name:"));
        inputPanel.add(productCombo);

        inputPanel.add(new JLabel("Product Price:"));
        inputPanel.add(priceField);

        // Process button
        JButton processButton = new JButton("Process");

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(inputPanel, BorderLayout.CENTER);
        topPanel.add(processButton, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);

        // Report area
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBorder(
            BorderFactory.createTitledBorder("Sales Report")
        );

        add(scrollPane, BorderLayout.CENTER);

        // Actions
        processButton.addActionListener(e -> processSale());
        processItem.addActionListener(e -> processSale());
        clearItem.addActionListener(e -> clearFields());
        exitItem.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    private void processSale() {

        try {
            String customer = customerField.getText().trim();
            String product = (String) productCombo.getSelectedItem();

            if (customer.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Please enter the customer name.");
                return;
            }

            double price = Double.parseDouble(
                priceField.getText().trim()
            );

            if (!Double.isFinite(price) || price <= 0) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid price greater than zero.");
                return;
            }

            ProductCalculations calculations = new ProductCalculations(price);

            double vat = calculations.GetVat();
            double commission = calculations.GetCommission();
            double total = calculations.GetTotal();

            String report = String.format(
                "MATTRESS SALES REPORT%n" +
                "--------------------------------------%n" +
                "Customer Name: %s%n" +
                "Product Name: %s%n" +
                "Product Price: R %.2f%n" +
                "VAT Amount (15%%): R %.2f%n" +
                "Commission (5%%): R %.2f%n" +
                "Total Sale Amount: R %.2f%n" +
                "--------------------------------------%n",
                customer, product, price, vat, commission, total
            );

            reportArea.setText(report);

            // Save sales information to data.txt
            try (FileWriter writer = new FileWriter("data.txt", true)) {
                writer.write(report);
                writer.write(System.lineSeparator());
            }

            JOptionPane.showMessageDialog(this,
                "Sale processed and saved to data.txt");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid numeric product price.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                "Error saving file: " + ex.getMessage());
        }
    }

    private void clearFields() {
        customerField.setText("");
        priceField.setText("");
        productCombo.setSelectedIndex(0);
        reportArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MattressSalesGUI());
    }
}