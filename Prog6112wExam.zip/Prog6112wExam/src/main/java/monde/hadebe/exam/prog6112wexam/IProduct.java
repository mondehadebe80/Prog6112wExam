package monde.hadebe.exam.prog6112wexam;


public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}