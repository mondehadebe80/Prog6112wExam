/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package monde.hadebe.exam.prog6112wexam;

/**
 *
 * @author apple
 */
public class Prog6112wExam {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
